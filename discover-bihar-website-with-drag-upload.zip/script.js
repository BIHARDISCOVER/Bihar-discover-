function toggleLanguage() {
  const enElements = document.querySelectorAll('[lang="en"], #title-en');
  const hiElements = document.querySelectorAll('[lang="hi"], #title-hi');
  enElements.forEach(el => {
    el.style.display = el.style.display === "none" ? "" : "none";
  });
  hiElements.forEach(el => {
    el.style.display = el.style.display === "none" ? "" : "none";
  });
}
